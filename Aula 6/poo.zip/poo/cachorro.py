from animais import Animais
class Cachorro(Animais):
    
    def __init__(self,nome,cor,raca):
        self.nome = nome
        self.cor = cor
        self.raca = raca
    def latir(self):
        print(self.nome, "esta latindo")
    def faz_barulho(self):
        return super().faz_barulho()