from numero import Numero
import math

math.sqrt()
class Fracao(Numero):
    
    def __init__(self,valor,conjunto):
        self.valor = valor
        self.conjunto = conjunto
        
    def soma(self):
        return self.valor + 1
n = Fracao(1,1)
print(n.soma())