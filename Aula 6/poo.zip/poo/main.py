from cachorro import Cachorro

pitch = Cachorro('Bela','Branca','pitch')
pitbull = Cachorro("Pitch","Marrom","Pitbull")

print(pitch.nome)
print(pitbull.nome)
pitch.latir()
pitbull.latir()
pitch.faz_barulho()