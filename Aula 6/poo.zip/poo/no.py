class No:
    
    def __init__(self,valor):
        self.valor = valor
    
    def set_proximo(self,proximo):
        self.proximo = proximo
    

if __name__ == '__main__':
    
    n1 = No(1)
    n2 = No(2)
    n3 = No(3)
    n4 = None
    
    
    n1.set_proximo(n2)
    n2.set_proximo(n3)
    n3.set_proximo(n4)
    
    
    def imprimir(no):
        while no != None:
            print(no.valor)
            no = no.proximo
            
    imprimir(n1)