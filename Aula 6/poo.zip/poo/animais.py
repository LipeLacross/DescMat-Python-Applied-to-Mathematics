class Animais:
    
    def __init__(self,nome):
        self.nome = nome
    def faz_barulho(self):
        print("animal fazendo barulho")