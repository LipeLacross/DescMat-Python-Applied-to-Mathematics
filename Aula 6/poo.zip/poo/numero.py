from abc import ABC ,abstractmethod

class Numero(ABC):
    
    @abstractmethod
    def __init__(self,valor,conjunto):
        pass
    
    @abstractmethod
    def soma(self):
        pass
    
